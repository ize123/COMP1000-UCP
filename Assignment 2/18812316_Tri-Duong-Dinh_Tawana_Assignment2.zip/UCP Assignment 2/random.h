#ifndef RANDOM_H
#define RANDOM_H

void initRandom();
int Random(int low, int high);

#endif
